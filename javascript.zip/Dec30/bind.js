const teacher = {
    firstName: 'Ajith',
    lastName: 'k',
    getFullName: function (age,subject){
        console.log(this);
        console.log('age',age);
        console.log('subject',subject);
        return `${this.firstName} ${this.lastName}`
    }
}
const guru = {
    firstName: 'guru',
    lastName: 'L'
}

//create a copy of the getFullName and it returns that
//function and this will be pointing to the objectpassed as first parameter

const getFullNameFunc = teacher.getFullName.bind(guru,10)
getFullNameFunc(['English'])
getFullNameFunc(['English','Kannada'])
getFullNameFunc(['English','Kannada'])



console.log('=============================================');


//constructor function

function Car(Name,year){
    this.Name = Name
    this.year = year
    console.log(this);
    this.getDetails = function(){
        return `${this.Name} manufactured year is ${this.year}`
    }
}

const Car1 = new Car("BMW",1947)
console.log(Car1.getDetails());

const Car2 = new Car("TATA",1900)
console.log(Car2.getDetails());




