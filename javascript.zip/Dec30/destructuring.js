const person = {
    firstName: 'Ajith',
    lastName: 'k',
    age: 10,
    hobbies: ['cricket','singing'],
    address: {
        state: 'karnataka',
        pincode: 569335,
        city: 'Bangalore'
    }
}

//const firstName = person.firstName
//const lastName = person.lastname
//const age = person.age


//object destructuring
const {firstName,lastName} = person 
console.log('firstName',firstName);
console.log('lastName',lastName);

console.log('===============================================');
//multi level destructuring
const {hobbies,address:{state,city}} = person 
console.log('hobbies',hobbies);
console.log('state',state);
console.log('city',city);

console.log('=========================================');
//alies name

const {firstName:fname,lastName:lname} = person 
console.log(fname);
console.log(lname);

function calculateTotalPrice({gst,price}){
    console.log('gst',gst);
    console.log('price',price);
    return price+(price*(gst/100))
}

const product = {
    price: 100,
    gst: 2,
    productName: 'bag',
    mfyear: 2021,
    moreDetails:{
        brand: 'skybag',
        color:'red'
    }
}
calculateTotalPrice(product);


console.log('=================================================');

//Array Destructuring

const fruits = ['Apple','orange','Banana','pineple']

//const fruit1 = fruit[0]
//const fruit2 = fruit[1]


//Array destructuring

const [fruit1,fruit2] = fruits 
console.log(fruit1);
console.log(fruit2);
