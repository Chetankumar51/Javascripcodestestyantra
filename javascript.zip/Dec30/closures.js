//Closures

function outer(){
    let count = 0
    function inner(){
        console.log('inner func');
        count = count+1 
        console.log('count',count);
    }
    return inner
}
const innerFunc = outer()
innerFunc()
innerFunc()

    //or

outer()()



//what is the use of closures and why we use closures
//1.To preserves the values
//2.for data privacy

function increaseCounter(){
    let counter = 0
    function updateCounter(){
        counter = counter + 1
        console.log(counter);
        return counter
    }
    return updateCounter
}
const counterIncrease = increaseCounter()
counterIncrease()
counterIncrease()
counterIncrease()




console.log('=============================');



//There is a 



function increaseCounter(){
    let counter = 0
    function updateCounter(){
        counter = counter + 1
        console.log(counter);
        return counter
    }
    return updateCounter
}

//self invoked fuction will be executed only once
//hence counter cannot be reinitionalized to 0 again
//only counter update function will be able to change the
//counter variable value

const counterInc = (function(){
    let counter = 0
    function counterUpdate(){
        counter = counter + 1
        console.log(counter);
        return counter
    }
    return counterUpdate
})()

counterInc()
counterInc()






