const person = {
    firstName: 'Ajith',
    lastName: 'k'
}

//spread operator and ES6 feature

//1.we can take shallow copy and deep copy


const personCopy = {...person}
const address = {
    pincode: 583226,
    state: 'Karanataka',
    city: 'Bangalore'
}
const personDetails = {...person, ...address}
console.log(personDetails);
const personC = {...person, age: 16}
console.log(personC);

const personD = {...person, lastName: 'j'}
console.log(personD);