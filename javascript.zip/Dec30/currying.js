// console.log('start')
// (10===10)? console.log('Equal') : console.log('not equal');


//semicolon is mandatory before () if you are
//writting () next line after executing any function
// or after ()

console.log('start');
(10===10)? console.log('Equal') : console.log('not equal');
console.log('end');

console.log('=========================================');

function test(){
    function inner(){
        console.log('inner function');
    }
    return inner
}

// const Val = test()
// //console.log(Val);
// Val()

// console.log(test());

//finction currying
test()()


// (function(){
//     console.log('Hello');
// })()


console.log('==================================================');





