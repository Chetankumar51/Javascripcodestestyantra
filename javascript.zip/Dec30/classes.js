
//constructor function

function Car(Name,year){
    this.Name = Name
    this.year = year
    console.log(this);
    this.getDetails = function(){
        return `${this.Name} manufactured year is ${this.year}`
    }
}

const Car1 = new Car("BMW",1947)
console.log(Car1.getDetails());

const Car2 = new Car("TATA",1900)
console.log(Car2.getDetails());



//Using Constructor method

class Car10 {
    constructor(Cname,Year) {
        this.Cname = Cname
        this.Year = Year
    }
    getCarDetails(){
        return `${this.Cname} is manufactured in the year ${this.Year}`
    }
}

const Car12 = new Car10("BMW",1856)
console.log(Car12.getCarDetails());


const Car13 = new Car10("TATA",1800)
console.log(Car13.getCarDetails());






