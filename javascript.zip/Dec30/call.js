const person={
    firstName:'Ajay',
    lastName:'G',
    getFullName:function(middleName){
        console.log(this);
        return `${this.firstName} ${middleName} ${this.lastName}`
    }
}
console.log(person.firstName);
console.log(person.lastName);
console.log(person.getFullName('kumar'));


const john={
    firstName:'john',
    lastName:'p'
}
console.log(john.firstName);
console.log(john.lastName);
console.log('===========================================');

//this will point to the object passed as first
// parameter to the call method
// Ex below: this will point to the john object insted of person object
const johnFullName=person.getFullName.call(john,'abraham')
console.log('Full name',johnFullName);

const fullName=person.getFullName.apply(john,['Abhram'])
console.log(fullName);