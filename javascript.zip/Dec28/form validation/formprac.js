let loginElement = document.getElementById('login')
loginElement.addEventListener('click',function(){
    let usernameVal = document.getElementById('username').value 
    let passwordVal = document.getElementById('password').value 

    let isUsernameValid = validateUsername(usernameVal)
    let isPasswordValid = validatePassword(passwordVal)
    if(isUsernameValid && isPasswordValid){
        console.log('Data is valid');
    }else{
        console.log('Data is invalid');
    }
})

function validateUsername(username){
    if(username){
        console.log(username);
        showUserNameError(false)
        return true
    }
    else{
        showUserNameError(true)
        return false
    }
}


function validatePassword(password){
    if(password){
        console.log(password);
        showPasswordError(false)
        return true
    }else{
        showPasswordError(true)
        return false
    }
}


function showUserNameError(isNameError){
    let ele = document.getElementById('usernameError')
    if(isNameError){
        ele.innerText = 'username not be empty'
        ele.style.display = 'block'
    }else{
        ele.innerText = ''
        ele.style.display = 'none'
    }
}

function showPasswordError(isError){
    let elem = document.getElementById('passwordError')
    if(isError){
        elem.innerText = 'password not be empty'
        elem.style.display = 'block'
    }else{
        elem.innerText = ''
        elem.style.display = 'none'
    }
}



