//document.write('Welcome to DOM session')
//if id is present it returns elements else null

const element = document.getElementById('demo')
console.log(element);
element.innerText = 'DOM'
element.style.backgroundColor = 'green'



//it returns single element

const pElement = document.querySelector('.test')
console.log(pElement);

const tagElement = document.querySelector('h1')
console.log(tagElement);

const idElement = document.querySelector('#demo')
console.log(idElement);


console.log('================================================');


//it returns array of elements if classname is present
const personElement = document.getElementsByClassName('person')
console.log(personElement);
personElement[2].innerText = 'mumbai'

for(let i=0; i<personElement.length; i++){
    if(i===0){
        personElement[i].innerText = 'vijay'
    }
    else if(i===1){
        personElement[i].innerText = 's'
    }
    else{
        personElement[i].innerText = 'Chennai'
    }
}


console.log('===============================================');
//it returns array of elements
//getElementByTagName
const pElements = document.getElementsByTagName('p')
console.log(pElements);

for(let i=0; i<pElements.length; i++){
    console.log(pElements[i]);
    pElements[i].style.color = 'blue'
    pElements[2].style.backgroundColor = 'brown'
}



console.log('=========================================================');

//it returns array of elements


// const personElementAll = document.querySelectorAll('.person')
// console.log(personElementAll);
// for(let i=0; i<personElementAll.length; i++){
//     personElementAll[i].style.border = '1px solid Black'
//     personElementAll[i].style.fontSize = '20px'
// }
// const pTags = document.querySelectorAll('p')
// console.log(pTags);
// pTags.style.color = 'red'


//create element

const h2Element = document.createElement('h2')
h2Element.innerText = 'This is h2 element'
console.log(h2Element);
h2Element.style.color = 'red'
document.body.appendChild(h2Element)


console.log('================================================');

const labelElement = document.getElementsByTagName('label')
//adding style based on css classes
//adding single class
labelElement[0].className = 'labelTag'
//adding multiple classes
labelElement[1].classList = 'labelBg labelTag'



console.log('==============================================================');


const userElement = document.getElementById('user')
//innerHtml will  the string as HTML code
userElement.innerHTML = '<h1>my name is ajith</h1>'


const userElement1 = document.getElementById('user1')
//innerText will parse the string as plain text or string itself

userElement1.innerText = '<h1>my name is ajith</h1>'


//to hide the element

const hobbiesListElement = document.getElementById('hobbieslist')
hobbiesListElement.style.display = 'none'

//to show the element
// const hobbiesListElement = document.getElementById('hobbieslist')
// hobbiesListElement.style.display = 'block' 













