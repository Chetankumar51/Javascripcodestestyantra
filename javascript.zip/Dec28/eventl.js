function testClick(){
    console.log('testClick executed');
}

function changeName(username){
    const element = document.getElementById('username')
    element.innerText = username
}

// function applyBColor(){
//     const element = document.getElementById('changeColor')
//     element.style.backgroundColor = 'red'
// }

// function removeBColor(){
//     const element = document.getElementById('changeColor')
//     element.style.backgroundColor = 'white'
// }

                  // or


function removeApplyBColor(color){
    const element = document.getElementById('changeColor')
    element.style.backgroundColor = color
}



function getData(){
    console.log('onkeyup');
}
function showData(){
    console.log('keydown');
}



console.log('======================================');

function getData(){
    const element = document.getElementById('randomData')
    console.log('onkeyup',element.value);
    document.getElementById('show').innerText = element.value.toUpperCase()
}

function checkBoxClick(){
    const element = document.getElementById('hobbies')
    console.log(element.checked);
}

function showData(){
    console.log('onkeydown');
}


console.log('================================================');









