const url = 'https://jsonplaceholder.typicode.com/posts'
const fetchPosts = ()=>{
    fetch(url).then((response)=>{
        console.log(response);
        return response.json()
    }).then((data)=>{
        console.log(data);
        let postData = '<ul>'
        // 'template literals'
        data.map((post)=>{
            postData+= `<li>${post.title}</li>`
        })
        postData += '</ul>'
        const divElement = document.getElementById('users') 
        divElement.innerHTML = postData 
        console.log('postData',postData); 
    }).catch(err=>{
        console.log(err);
        console.error(err.message);
    })
}
fetchPosts()

