const url = 'https://jsonplaceholder.typicode.com/posts'
const fetchPosts = ()=>{
    fetch(url).then((response)=>{
        console.log(response);
        return response.json()
    }).then((data)=>{
        console.log(data);
        let postData = '<ul>'
        // 'template literals'
        data.map((post)=>{
            postData+= `<li>${post.title}</li>`
        })
        postData += '</ul>'
        const divElement = document.getElementById('users') 
        divElement.innerHTML = postData 
        console.log('postData',postData); 
    }).catch(err=>{
        console.log(err);
        console.error(err.message);
    })
}
fetchPosts()


function savePost(){
    const post = {
        userId: 1000,
        title: 'javascript end game',
        body: 'javascript javascript'
    }
    fetch(url,{
        method: 'POST',
        body: JSON.stringify(post),
        headers:{
            'content-Type' : 'application/json'
        }

    }).then((response)=>{
        console.log(response);
        return response.json()
    }).then(data=>{
        console.log('Added post',data);
    })
}