const jsonObject = {
    firstName: 'Ajay',
    lastName: 'k',
    age: 17,
    isAdult: false,
    hobbies: ['cricket','singing'],
    address: {
        pincode: 560018,
        state: 'Karanataka',
        city: 'Bangalore',
    }
}

console.log('javascript to JSON');
const stringfiJson = JSON.stringify(jsonObject)


console.log(stringfiJson);
console.log(typeof stringfiJson);

console.log('JSON to javascript');

const javascriptObject = JSON.parse(stringfiJson)
console.log(javascriptObject);