console.log('started');

const myPromise1 = new Promise((resolve,reject)=>{
    setTimeout(()=>{
        resolve([100,200,300,400])
    },3000)
})

const myPromise2 = new Promise((resolve,reject)=>{
    setTimeout(()=>{
        resolve([900,1000,1200])
    },5000)
})

const myPromise3 = new Promise((resolve,reject)=>{
    setTimeout(()=>{
        resolve([900,1000,1200,50])
    },2000)
})

Promise.race([myPromise1,myPromise2,myPromise3]).then((data)=>{
    console.log('Data',data);
}).catch(err =>{
    console.log('err',err);
})

console.log('ended');


