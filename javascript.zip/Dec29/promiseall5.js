console.log('started');

const myPromise1 = new Promise((resolve,reject)=>{
    setTimeout(()=>{
        resolve([100,200,300,400])
    },3000)
})

const myPromise2 = new Promise((resolve,reject)=>{
    setTimeout(()=>{
        resolve([900,1000,1200])
    },5000)
})

// If all promises are resolved then function will 
// be executed and it will combine the resolved data 
// into Array.
// if any one promise is rejected also catch function 
// will be executed

Promise.all([myPromise1,myPromise2]).then((data)=>{
    console.log('Data',data);
}).catch(arr =>{
    console.log('err',err);
})

console.log('ended');


