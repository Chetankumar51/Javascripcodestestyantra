// var names = ['puneeth','sudeep','upedra','rakshith','dolly','NTR'];
// console.log(names);
// console.log(names.length);
// console.log(names[0]);
// console.log(names[1]);
// console.log(names[2]);
// console.log(names[4]);


// for(let i=0; i<=5; i++){
//     console.log("Hello");
// }


// for(var i=0; i<names.length; i++){
//    debugger
//     console.log(names[i]);
// }


// var myArray = ["ajay",34, true, undefined, null, {color: "black"}, ["black", "blue", "red"]];

// console.log(myArray[2]);             //true
// console.log(myArray[4]);                //null
// console.log(typeof(myArray[3]));        //undefined
// console.log(myArray.length);            //7
// console.log(myArray[5].length);         //undefined
// console.log(myArray[5].color);          //black
// console.log(myArray[5]['color']);       //black
// console.log(myArray[5]['co lor']);      //undefined
// console.log(myArray[6].length);         //3
// console.log(myArray[6][0]);             //black
// console.log(myArray[6][2-1]);           //blue

console.log("======================================================");

var books = [
    {
    author: "chetan Bhagat",
    title: "Two states",
    price: 80,
    noOfPages: 265,
    publisher: "sapna"
},

{
    author: "paulo cohello",
    title: "Alchmist",
    price: 180,
    noOfPages: 265,
    publisher: "Harper Torch"
},


{
    author: "Purnachadra Tejaswi",
    title: "Chidambar Rahasya",
    price: 340,
    noOfPages: 500,
    publisher: "sahitya Bhandara"
}

];

for(var i=0; i<books.length; i++){
    console.log(books[i]);
}


console.log("===========================================================");



// creating array using new keyward

var array = new Array(10);
console.log(array.length);
console.log(array[0]);

console.log("=====================================================");


var array = new Array(10,12);
console.log(array.length);
console.log(array[0]);
console.log(array[1]);

console.log("=====================================================");


var colors = new Array("blue");
console.log(colors.length);
console.log(colors[0]);


console.log("=====================================================");


var car = new Object()
car.price = 1400000;
car.model = 2018;
car.brand = "Toyota";
car.name = "Fortuner";
car.color = "pink";
console.log(car);
console.log(car.price);
console.log(car.model);
console.log(car.brand);
console.log(car.name);
console.log(car.color);
