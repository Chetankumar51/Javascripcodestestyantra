// system date
// console.log("DATE OBJECT");
// var systemDate = new Date()
// console.log(systemDate);
// console.log(systemDate.getFullYear());
// console.log(systemDate.getHours());
// console.log(systemDate.getDate());
// console.log(systemDate.getMonth());   //December or 11
// console.log(systemDate.getDay());      //Tuesday or 2


// var getMilliSeconds = new Date(86400000)
// console.log(getMilliSeconds);

// var dateStringCount = new Date('Dec,12,2020')
// console.log(dateStringCount);
// console.log(dateStringCount.getFullYear());
// console.log(dateStringCount.getHours());
// console.log(dateStringCount.getDate());
// console.log(dateStringCount.getMonth());   
// console.log(dateStringCount.getDay());      


// var dateval = dateStringCount.getDate();
// var monthval = dateStringCount.getMonth();
// var yearval = dateStringCount.getFullYear();

// var FullYear = `(${dateval}/${monthval+1}/${yearval})`
// console.log(FullYear);


// console.log("=============================================================");


// var dateObj = new Date(2012,12)
// console.log(dateObj);
// var dateObj1 = new Date(2012,17,21)
// console.log(dateObj1);
// var dateObj2 = new Date(2021,1,21,12,56.56,864)
// console.log(dateObj2);


// console.log("===========================================================");


// var systemDate1 = new Date();
// var systemDay = systemDate1.getDay();
// var systemMonth = systemDate1.getMonth();
// var systemDate = systemDate1.getDate();
// var systemYear = systemDate1.getFullYear();


// let months = ["january","Feb","march","April","May","June","July","August","septmber","Octomber","November","December"]
// var month = months[11];

// let weeks = ["sunday","monday","Tuesday","wednesday","thursday","friday","saturday"];
// var week = weeks[2];

// var FullDate = `${week}/${month}/${systemDate}/${systemYear}`
// console.log(FullDate);


console.log("==========================================================");


var dateObjVal = new Date()
console.log(dateObjVal);

var formattedDatel = dateObjVal.toLocaleDateString('eng-us',
{
    weekday: 'long',
    month: 'short',
    year: 'numeric',
    day: 'numeric'

})

console.log(formattedDatel);




