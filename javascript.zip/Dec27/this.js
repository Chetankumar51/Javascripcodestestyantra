//gobal level this is equal to window object
//this will always point to the current object

console.log(this);
console.log(window);
console.log(this===window);


console.log('===============================================');

const person = {
    firstName: 'Ajith',
    lastName : "k",
    getFullName: function(){
        //this is person object
        console.log('this inside getFullName - ',this);
        return this.firstName + ' ' + this.lastName
    }
}
person.getFullName()


function greet(){
    //this is equal to window object
    //all the global properties and functions
    //belong to window object
    //(greet will be invoked usig window reference)
    console.log('this inside greet - ', this);
    console.log('greet func');
}
window.greet()
greet()

console.log('=====================================================');

const myObj = {
    getData: function() {
        function test() {
            //this is equal to window object
            //because test() is not invoked by 
            //any object reference
            console.log('this inside test func',this);
            console.log('test func');
        }
        test()
    }
}
myObj.getData()



console.log('==============================================================');

const myObj1 = {
    firstName: 'vijay',
    lastName: 's',
    getName: function(){
        const test = () =>{
            //Arrow function will not have its own
            //this. this will refer to its parent
            //execution context
            console.log('this inside test',this);
            console.log('test func');
        }
        test()
        return `${this.firstName} ${this.lastName}`
    }
}

myObj1.getName()

console.log('======================================================');


const myObj2 = {
    firstName: 'vijay',
    lastName: 's',
    getName: ()=>{
        const test1 = () =>{
            //this inside getResults - window
            // refers to its parent context
           console.log('getResult', this);
        },
        getResult: function(){
            const test1 = ()=>{
                //Arrow function will not have its own
                //this. this will refere to its execution context
                console.log('this inside test',this);
                console.log('test func');
            }
        }
        test1()
        return `${this.firstName} ${this.lastName}`
    }
}

myObj2.getName()
myObj2.getResult()


// 1.this is global - window
// 2.this is named function which is declared in global level-window 
// 3.this is named function which is invoked using object 
// reference - current object 
// 4.this is arrow function which is invoked using 
// object reference - parent context object 
// 5. A named function declared inside a function 
// which is invoked using object reference - window object 
// 6. An Arrow function declared inside a function which 
// is invoked using object reference - parent context object

