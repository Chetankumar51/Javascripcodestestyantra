//string mrethods
console.log('===========toUpperCase==============');
const str = 'Hello'
str.toUpperCase()
const result = str.toUpperCase()
//because primitive types are immutable
console.log(str);        //Hello
console.log(result);    //HELLO


console.log('======toLowerCase============');

//tolowercase

let greet = 'Good Afternoon'
greet = greet.toLowerCase()
console.log(greet);    //good afternoon

console.log('=========charAt method=========');
console.log(greet.charAt(13));

console.log('==========indexOf method=============');
console.log(greet.indexOf('o',10));

console.log('======concat method===============');
const res = str.concat(',',greet,'all')
console.log(res);

console.log('==========includes===============');
const hasNoon = greet.includes('noon')
console.log('hasNoon',hasNoon);

console.log('=============replace method=================');
const value = greet.replace('afternoon','night')
console.log(value);

console.log('================substr method=============');

const data = 'Hello all, welcome to javascript session'
const extractedStr = data.substr(11,10)
console.log(extractedStr);


console.log('===========substring=================');
//end is not included

const subStrVal = data.substring(1,4)
console.log(subStrVal);


console.log('============trim method==============');

const email = '                 chetanpd51@gmail.com       '
console.log('email', email);
const mailAfterTrim = email.trim();
console.log('mailAfterTrim', mailAfterTrim);

const gmail = '              pavan@gmail.com     '
console.log('start', gmail.trimStart());
console.log('end', gmail.trimEnd());









