//Map method


//  const newArr = [100,200,300,400,500] 
// const newArrCopy = [] 
// for(let i=0; i<newArr.length; i++){
//     newArrCopy.push(newArr[i]*10)
// }
// console.log(newArrCopy);


console.log('==========Map method===============');
//or

const numsArr = [100,200,300,400,500] 
const newCopyArr = numsArr.map((value,index,arr)=>{
    return value+10
    // if(index===0){                   //110
    //     return value+10
    // }
    // else{
    //     return value
    // }
})
console.log(numsArr);        //100,200,300,400,500
console.log(newCopyArr);     //110,210,310,410,510


console.log('=====Filter method==============');
//filter method


const ageArr = [45,56,9,89,10,5] 
const filterAgesArr = ageArr.filter((value)=>{
    if(value>=10){
        return true
    }
    else{
        return false
    }
})
console.log(filterAgesArr);       // [45,56,89,10]  


//or

const filterAge = ageArr.filter((value)=>{
    return value>=18
})
console.log(ageArr);
console.log(filterAge);

//or

const filterAges = ageArr.filter((value)=>value>=18)
console.log(filterAges);




const books = [
    {
        title: "harry potter",
        price: 90,
        author: "pavan"
    },
    {
        title: "Indian Constitution",
        price: 720,
        author: "Laxmi kanth"
    },
    {
        title:"wings of fire",
        price: 130,
        author: "apj abdul kalam"
    }
]

const bookWithGst = books.map(book=>{
    books.price = book.price*0.18 + book.price
    return books.price
})

console.log(books);
console.log(bookWithGst);     //[106.2,849,177]

console.log("======Deep copy using spread operaror=======");

const bookWithGstDeepCopy = books.map(book=>{
    const b = {...book}
    b.price = b.price*0.18 + b.price 
    return b
})

console.log(bookWithGstDeepCopy);
console.log(books);


console.log('==================================================================================');








const products = [
    {
        productName: 'Lipstick',
        price: 999,
        brand: 'maybeline'
    },
    {
        productName: 'Eyeliner',
        price: 500,
        brand: 'lakme'
    },
    {
        productName: 'trimmer',
        price: 1000,
        brand: 'Philips'
    },
    {
        productName: 'beard oil',
        price: 260,
        brand: 'Beardo'
    }
]


const productWithGst = products.map(products => {
    const productCopy = {...products}  
    productCopy.price = productCopy.price*0.03+products.price
    return productCopy
})

console.log(products);
console.log(productWithGst);


const filterProductCopy = products.filter((product)=>{
    if(product.price > 500){
        return true
    }
    else{
        return false
    }
    // return value>500
})
console.log(filterProductCopy);





console.log('=================important===================================');


 
//       // reference copy
// const booksCopy = books
// console.log(books===booksCopy);    //true


// const booksCopy = {...books}
// console.log(books===booksCopy);   //false
// console.log(books[0]===booksCopy[0]);   //true




// books[0].price = 100
// console.log(books[0].price);     //100
// console.log(booksCopy[0].price);   //100


// const booksCopy = books.map(book=>{
//     return {...book}
// })

// console.log(booksCopy);
// console.log(books[0]===booksCopy[0]);     //false


// books[0].price = 100
// console.log(books[0].price);        //100
// console.log(booksCopy[0].price);    //90



console.log('=========Join method=======================');

//to convert the array to string method
const myArr = [100,200,300,400,500] 
const str = myArr.join('-') 
console.log('str',str);



const fruits = ['Apple','pineapple','custard Apple','Green Apple'] 
//o/p - Apple,pineapple,custard Apple,Green Apple
const fruitStr = fruits.join(',')
console.log('fruitStr',fruitStr);





