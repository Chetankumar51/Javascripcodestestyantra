//To find minimum

var minVal = Math.min(21,35,65,965,45,7,8);
console.log('Min Value -', minVal);

//To find Maximum value

var maxVal = Math.max(21,35,65,965,45,7,8);
console.log('Max Value -', maxVal);

//To find power

var powerVal = Math.pow(2,3);
console.log('power of 2,3 is', powerVal);

var powerVal = Math.pow(3,8);
console.log('power of 3,8 is', powerVal);


var absVal = Math.abs(-12);
console.log(absVal);

var ceilVal = Math.ceil(23.8);
console.log(ceilVal);


var floorVal = Math.floor(23.8);
console.log(floorVal);


var randomVal = Math.random()
console.log(randomVal);


// To get random index and names

var names = ["ramesh","suresh","ajay","vijay"]
console.log(Math.floor(Math.random()*3));
var randomIndex = Math.floor(Math.random()*names.length);
console.log(names[randomIndex]);


//To get random values from 0 to 100

console.log(Math.ceil(Math.random()*100));



