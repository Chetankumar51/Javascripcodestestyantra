// //named functions

// function add(num1,num2){
//     var sum = num1 + num2
//     console.log(sum);
// }
// add(10,20);
// add(55,24);

// console.log("=================================================================");


// // to find eligibility or voting

// function findEligibleForVoting (age){
//     if(age>=18){
//         return true
//     }
//     else{
//         return false
//     }
// }

// function printEligiblePerson(result){
//     if(result===true){
//         console.log("Eligible for voting");
//     }
//     else{
//         console.log("Not eligible");
//     }
// }

// var result1 = findEligibleForVoting(12);
// printEligiblePerson(result1);

// var result2 = findEligibleForVoting(34);
// printEligiblePerson(result2);


// console.log("============================================================");



//Anonymous functions

var findProduct = function(a,b){
    return a*b;
}
console.log(findProduct);
var productVal = findProduct(12,3);
console.log("product", productVal);


var person = {
    testFunc : function(){
        console.log("test function executed");
    }
}

person.testFunc();


console.log("=====================================================");



// Self Invoked functions (IIFE)
// Immediately Invoked Function Expression

(function(a,b){
    var diff = b-a 
    console.log("Difference", diff);
})(20,10)


console.log("=============================================================");
//Arrow function (ES6 feature)


var greet = () =>{
    console.log("greet function");
    console.log("welcome");
}
greet();

console.log("===========================================");


var squareOfNumber = num=>num*num
var result = squareOfNumber(2);
console.log("Result",result);
console.log(squareOfNumber(3));

console.log("=================================================");


var calculateTotalPrice = (price,gst) => {
    var totalPrica = (price*gst/100)+price 
    return totalPrica
}

var priceVal = calculateTotalPrice(120,18)
console.log(priceVal);

