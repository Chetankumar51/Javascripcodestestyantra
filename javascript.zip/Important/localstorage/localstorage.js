function setName () {
    localStorage.setItem('username','Ajit')
    localStorage.setItem('age',18)
}

function updateName() {
    localStorage.setItem('username','Guru')
}

function getName () {
    const value = localStorage.getItem('username')
    console.log(value);
}

function clearLocalStorage () {
    // clears all key value from localstorage
    localStorage.clear()
}
function clearUserName() {
    // removes only username key value 
    localStorage.removeItem('username')
}