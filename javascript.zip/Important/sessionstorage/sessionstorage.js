function setName () {
    sessionStorage.setItem('username','Ajit')
    sessionStorage.setItem('age',18)
}

function updateName() {
    sessionStorage.setItem('username','Guru')
}

function getName () {
    const value = sessionStorage.getItem('username')
    console.log(value);
}

function clearsessionStorage () {
    // clears all key value from sessionStorage
    sessionStorage.clear()
}
function clearUserName() {
    // removes only username key value 
    sessionStorage.removeItem('username')
}