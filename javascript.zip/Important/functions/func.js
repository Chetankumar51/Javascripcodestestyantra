(function () {
    function greet() {
        console.log('greet of func');
    }
    
})()
