const person = {
    firstName: 'Ajit',
    lastName: 'K',
    age: 10,
    hobbies: ['Cricket', 'Singing'],
    address: {
        state: 'Karnataka',
        pincode: 560068,
        city: 'Bangalore'
    }
}
// const firstName = person.firstName
// const lastName = person.lastName
// const age = person.age

// Object Destructuring (ES6 feature)
const { firstName, lastName } = person
console.log('First name', firstName);
console.log('Last name', lastName);
// multi level destructure
const { hobbies, address: { state, city } } = person
console.log('hobbies', hobbies);
console.log('state', state);
console.log('city', city);

// alias names
const { firstName: fname, lastName: lname } = person
console.log(fname);
console.log(lname);
function calculateTotalPrice({ gst, price }) {
    console.log('gst', gst);
    console.log('price', price);
    return price + (price * (gst/100))
}
const product = {
    price: 100,
    gst: 3,
    productName: 'Bag',
    mfgYear: 2021,
    moreDetails: {
        brand: 'Wildcraft',
        color: 'blue'
    }
}
calculateTotalPrice(product)

const fruits = ['Apple','PineApple','Orange','Banana']

// const fruit1 = fruits[0]
// const fruit2 = fruits[1]

// Array destructuring
const [fruit1,fruit2] = fruits
console.log(fruit1);
console.log(fruit2);

const [fruitOne,,fruitThree] = fruits
console.log(fruitOne);
console.log(fruitThree);

console.log('---------------------------------');

