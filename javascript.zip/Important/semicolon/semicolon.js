// console.log('start')
// (10===10?console.log('Equal'):console.log('NotEqual'))

// semicolon is mandatory before () if you are
// writing () next line after executing any function
// or after () 
console.log('start');
(10 === 10 ? console.log('Equal') : console.log('NotEqual'))
console.log('end')
console.log('-------------------');
function test() {
    function inner() {
        console.log('Inner function');
    }
    return inner
}

// const val = test()
// console.log(val);
// val()

// console.log(test())

// Function currying
test()();

(function () {
    console.log('hello');
})()

console.log('------------------------');

function outer() {
    let count = 0
    function inner() {
        console.log('inner func');
        count=count+1
        console.log('count', count);
    }
    return inner
}

const innerFunc = outer()
innerFunc()
innerFunc()




