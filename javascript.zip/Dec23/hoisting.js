console.log('a -', a)       //undefined
var a = 10
var b = 30          //Global variables
console.log('b outsidefunction - ',b);

function test(){
    //variable Hoisting inside function
    //local variables will be given first preparence
    //if the variable will not declared locally js engine
    //will search the variable in global scope
    //if the variable is declared locally js engine
    //will not search the variable in global scope
    console.log('b inside function',b);
    var b = 20                              //local variables
    console.log('a inside function - ',a);
}
test();

// output

// a - undefined
// b outsidefunction -  30
// b inside function undefined
// a inside function -  10



console.log("====================================================");


//function hoisting

add(10,20)

function add(a,b){
    console.log(a+b);
}



console.log("=======================================================");


//greet() 
//calling the anonymus function before
//assigning the function will result in error
//i.e.,greet is not a function because the greet
//variable will be hoisted in the top as a variable


// greet()
var greet = function(){
    console.log("welcome");
}
greet()

console.log("=========================================");

// var greet
// greet()                         //greet is a function
// greet = function(){
//     console.log("welcome");
// }


console.log("============================================");

//product()
//calling a arrow function before
//assigning the function to variable will result in
//error i.e.,greet is not a function because the product.


var product = (a,b)=>{
    console.log(a*b);
}
product(10,2);










