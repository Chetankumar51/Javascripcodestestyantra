
//push methos

var hobbies = ["sleeping", "coding", "treaking", "Bird watching"]

var hobbiesLength = hobbies.push('reading')
console.log('hobbies after push',hobbies);         //[" "]
console.log('hobbiesLength',hobbiesLength);

console.log('hobbies', hobbies.push('cooking'));


console.log(hobbies);






console.log("================pop method========================");

//pop method

var deleteElement = hobbies.pop()
console.log('hobbies after pop', hobbies);
console.log('deleteElement', deleteElement);


console.log(a);
var a;
a = 20;


console.log("===================Unshift method=============================");

//unshift method - add the element at the start of the arry.

const lengthHobbies = hobbies.unshift('Gaming')
console.log('hobbies after unshift', hobbies);
console.log('hobbies length after unshift', lengthHobbies);


console.log("=================Shift method=========================");


//shift method-removes the element at the start of the array

const deletehobbies = hobbies.shift()
console.log('hobbies after shift', hobbies);
console.log('deleted hobby after shift', deletehobbies);

console.log("==============Splice method====================");


       //splice method
//splice(start index, delete count, elements)
const numbers = [10,20,30,40,50]
const deleteElemen = numbers.splice(2,2,60,70,80)
console.log('deleteElemen',deleteElemen);   //30,40
console.log('numbers',numbers);    //10,20,60,70,80,50

console.log('========================================');

//if we want to only add elements without deleting
//pass delete count as 0(second parameter)
const deletementElement1 = numbers.splice(1,0,100,110)
console.log('deletementElement1',deletementElement1);
console.log('numbers',numbers);


console.log('==================Slice method================================');


//slice method

const nums = [10,20,30,40,50] 
const deleteNums = nums.slice(1,3)
console.log('deleteNums', deleteNums);    //20,30
console.log('nums',nums);                  //10,20,30,40,50

//shallowcopy of array

const numsCopy = nums.slice(0)
console.log('numsCopy', numsCopy);    //10,20,30,40,50
console.log('nums', nums);              //10,20,30,40,50
nums[0] = 1000
console.log(nums[0]);       //1000
console.log(numsCopy[0]);   //10


//copy (address is copied)
//changing n will also change n1
const n = [10,20]
const n1 = n
n[0] = 90
console.log(n[0]);       //90
console.log(n1[0]);      //90



const movies = ['Spiderman','Batman','antam','Iron man'] 
//shallow copy using spread operator for array
const moviesCopy = {...movies}
movies[0] = 'Shakthiman'
console.log(movies[0]);       //Shakthiman
console.log(moviesCopy[0]);  //Spiderman


console.log('====================typeof method============================');

console.log('type of hobbies', typeof(hobbies));

//isArray method
//isArray returns true if its array else return false
const isHobbyArray = Array.isArray(hobbies)
console.log('isHobbyArray', isHobbyArray);


console.log("==================includes method==================");
console.log(hobbies);

//Includes method
//check wether element is present or not
//if present return true else false
const iscodingPresent = hobbies.includes("coding")
console.log('iscodingpresent', iscodingPresent);

console.log("====================indexof method======================");

//IndexOf method
//check wether element is present or not
//if present return the index of element or else -1
const isIndexofreading = hobbies.indexOf("reading")
console.log('index of reading', isIndexofreading);

console.log("================forEach method========================");

//forEach method(callbackfunc)

hobbies.forEach(function(value,ind,arr){
    console.log(`${ind} - ${value} - ${arr}`);
})

