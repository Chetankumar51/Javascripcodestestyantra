// console.log("start")

// function add(a,b){
    
//     setTimeout(()=>{
//         console.log("111");
//     },2000)

//     console.log(a+b);
// }
// add(10,20)

// setTimeout(function(){
//     console.log("ABC");
// },3000)


// console.log("end");



console.log("==========================================================");


//Callback function

function first(callback){
    // console.log(callback);
    setTimeout(()=>{
        console.log("first executed");
        callback();
    },0)
}

function second(){
    console.log("second executed");
}

first(second);